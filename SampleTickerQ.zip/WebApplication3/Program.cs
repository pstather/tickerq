using Microsoft.EntityFrameworkCore;
using TickerQ.Caching.StackExchangeRedis.DependencyInjection;
using TickerQ.Dashboard.DependencyInjection;
using TickerQ.DependencyInjection;
using TickerQ.EntityFrameworkCore.DbContextFactory;
using TickerQ.EntityFrameworkCore.DependencyInjection;
using TickerQ.Instrumentation.OpenTelemetry;

var builder = WebApplication.CreateBuilder(args);

_ = typeof(ClassLibrary1.TestSystem2);
builder.Services.AddTickerQ(x =>
{
  x.AddStackExchangeRedis(y =>
  {
    y.Configuration = "127.0.0.1:6379";
    y.NodeHeartbeatInterval = TimeSpan.FromMinutes(1);
  });
  x.AddOpenTelemetryInstrumentation();
  x.AddDashboard(y =>
  {
    y.WithNoAuth();
    y.SetBasePath("/background");
  });
  x.AddOperationalStore(y =>
  {
    y.SetDbContextPoolSize(34);
    y.UseTickerQDbContext<TickerQDbContext>(z =>
    {
      z.UseInMemoryDatabase("TickerQ");
    });
  });
  x.ConfigureScheduler(y =>
  {
    y.SchedulerTimeZone = TimeZoneInfo.Local;
  });
});

var app = builder.Build();

app.UseTickerQ();

app.MapGet("/", () => "Hello World!");

app.Run();