﻿namespace WebApplication3;

public class Test2Input
{
  public string Input { get; init; }
  public int SecondsTimeout { get; init; }
}