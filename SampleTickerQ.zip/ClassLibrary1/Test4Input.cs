﻿namespace ClassLibrary1;

public record Test4Input(string Input, int SecondsTimeout);